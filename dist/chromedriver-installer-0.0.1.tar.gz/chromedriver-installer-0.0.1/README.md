# Chromedriver-Install
Python script that installs the proper Chromedriver in accordance to the current Chrome browser version

### Usage
```bash 
python3 chromedriver.py /chromedriver/install/path
```
